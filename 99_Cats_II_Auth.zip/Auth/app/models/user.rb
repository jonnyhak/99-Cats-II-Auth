class User < ApplicationRecord
    validates :username, presence: true, uniqueness: true 
    validates :session_token, presence: true, uniqueness: true 
    validates :password_digest, presence: {message: "password cannot be blank"}
    validates :password, length: {minimum: 6, allow_nil: true}

    before_validation :ensure_session_token
    attr_reader :password

    has_many :cats,
        foreign_key: :user_id,
        class_name: :Cat 

    def reset_session_token! 
        self.session_token = SecureRandom::urlsafe_base64
        self.save!
        self.session_token 
    end 

    def password=(password)
        @password = password 
        self.password_digest = BCrypt::Password.create(password)
    end 

    def is_password?(password)
        b = BCrypt::Password.new(self.password_digest)
        b.is_password?(password)
    end 

    def self.find_by_credentials(user_name, password)
        user = User.find_by(username: user_name)
        return nil unless user && user.is_password?(password)
        user 
    end

    def ensure_session_token 
        self.session_token ||= SecureRandom::urlsafe_base64
    end 

end
